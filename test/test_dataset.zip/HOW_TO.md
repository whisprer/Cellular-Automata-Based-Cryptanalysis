in this `.ZIP` are a selection of different ordere and unordered dta files as raw `.bin.

please:

i) copy file.
ii) add letter sequential e,g, A,B,C, etc.
iii) encrypt all A's one way, all B's another etc.

iv) keep record but don't leave clue for me.
v) submit to me for analysis.
vi) review my guesses and pass back inf as to if correct.

vii) give great commendations to the genius wofl who thanx you for your fail at hiding encrypted data form me



